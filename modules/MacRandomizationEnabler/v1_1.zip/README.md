# MacRandomizationEnabler for Android 10(+)

The purpose of this magisk module is to enable Mac Randomization on your device in case it was left turned off by your OEM
I've only encountered this with the Essential Phone so far, but it's possible there's others.

## Requirements
- Android 10(+)
- Magisk 20+

## Installation
1. Flash this module.
2. Reboot.
3. Ensure the privacy dropdown now shows up on your WiFi network
![alt text](https://i.imgur.com/SuIwBTf.png)
4. Enjoy!

## Links
- [GitHub](https://github.com/Magisk-Modules-Alt-Repo/MacRandomization)
- [Donate](https://paypal.me/aozahoski)

## Changelog

### v1.0
- Initial release
