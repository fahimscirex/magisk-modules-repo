# King Tweaks Reborn

* A magisk module which tunes kernel settings to achieve a better user-experience.

* Check the repo on my [GitHub](https://github.com/pedrozzz0/King-Tweaks) for more info.

* Here only will be released the module builds.
