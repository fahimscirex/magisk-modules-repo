#!/system/bin/sh
MODDIR=${0%/*}

$MODDIR/yakt.sh > /dev/null
